"""MCP tools reaching the AI analyst: namespacing, allowlisting, routing and failure containment."""
import json

import pytest

from app.adapters.base import ProviderError
from app.intelligence.mcp_tools import MCPToolset, PREFIX, qualified_name


def test_namespacing_cannot_shadow_an_internal_tool():
    from app.intelligence.tools import TOOL_SPECS

    internal = {t["name"] for t in TOOL_SPECS}
    # Even a server that names its tool exactly like ours ends up distinct.
    assert qualified_name("srv", "get_plan") not in internal
    assert qualified_name("srv", "get_plan").startswith(PREFIX)


def test_namespacing_sanitises_and_truncates():
    name = qualified_name("my server!", "Weird Tool/Name")
    assert name == "mcp__my_server__weird_tool_name"
    assert len(qualified_name("x" * 40, "y" * 60)) <= 64


def test_toolset_routes_only_its_own_names():
    ts = MCPToolset()
    assert ts.handles("mcp__srv__thing") is True
    assert ts.handles("get_plan") is False


def test_unknown_mcp_tool_returns_an_error_not_an_exception():
    assert json.loads(MCPToolset().call("mcp__srv__nope", {}))["error"].startswith("unknown MCP tool")


def test_a_failing_tool_is_reported_to_the_model_rather_than_ending_the_run(monkeypatch):
    ts = MCPToolset()
    ts._routes["mcp__srv__boom"] = ({}, {"server_url": "https://x.example.com/mcp"}, "boom")

    class Boom:
        def call_tool(self, *a, **k):
            raise ProviderError("quota exceeded")

    ts._clients["https://x.example.com/mcp"] = Boom()
    out = json.loads(ts.call("mcp__srv__boom", {}))
    assert out["error"] == "quota exceeded"


def test_an_unexpected_exception_is_also_contained(monkeypatch):
    ts = MCPToolset()
    ts._routes["mcp__srv__bad"] = ({}, {"server_url": "https://x.example.com/mcp"}, "bad")

    class Bad:
        def call_tool(self, *a, **k):
            raise RuntimeError("socket died")

    ts._clients["https://x.example.com/mcp"] = Bad()
    assert "RuntimeError" in json.loads(ts.call("mcp__srv__bad", {}))["error"]


def test_tool_results_are_truncated_so_one_call_cannot_blow_the_context():
    from app.intelligence.mcp_tools import MAX_RESULT_CHARS

    ts = MCPToolset()
    ts._routes["mcp__srv__big"] = ({}, {"server_url": "https://x.example.com/mcp"}, "big")

    class Big:
        def call_tool(self, *a, **k):
            return {"content": [{"type": "text", "text": "x" * 100_000}]}

    ts._clients["https://x.example.com/mcp"] = Big()
    assert len(ts.call("mcp__srv__big", {})) == MAX_RESULT_CHARS


def test_load_toolset_only_offers_allowlisted_tools(monkeypatch):
    from app.intelligence import mcp_tools

    class FakeConn:
        provider_key, is_enabled, project_id = "mcp_analyst", True, None
        display_name = "Docs server"
        credentials_encrypted = None
        config = {"server_url": "https://d.example.com/mcp", "analyst_tools": "search_docs"}

    class FakeClient:
        def list_tools(self):
            return [{"name": "search_docs", "description": "Search", "inputSchema": {"type": "object"}},
                    {"name": "delete_everything", "description": "Danger", "inputSchema": {"type": "object"}}]

    monkeypatch.setattr(mcp_tools, "build_client", lambda c, cfg: FakeClient())
    monkeypatch.setattr(mcp_tools, "decrypt_credentials", lambda b: {})

    class FakeDB:
        def scalars(self, *a, **k):
            class R:
                def all(self_inner):
                    return [FakeConn()]
            return R()

    ts = mcp_tools.load_toolset(FakeDB(), "pid")
    assert [t["name"] for t in ts.specs] == ["mcp__docs_server__search_docs"]
    assert "delete_everything" not in json.dumps(ts.specs)       # never offered, even though the server has it
    assert ts.specs[0]["description"].startswith("[Docs server]")  # provenance is visible to the model


def test_load_toolset_skips_a_connection_with_no_allowlist(monkeypatch):
    from app.intelligence import mcp_tools

    class FakeConn:
        provider_key, is_enabled, project_id = "mcp_backlinks", True, None
        display_name = "Backlinks"
        credentials_encrypted = None
        config = {"server_url": "https://b.example.com/mcp"}      # no analyst_tools

    class FakeDB:
        def scalars(self, *a, **k):
            class R:
                def all(self_inner):
                    return [FakeConn()]
            return R()

    assert mcp_tools.load_toolset(FakeDB(), "pid").specs == []


def test_an_unreachable_server_is_recorded_and_skipped(monkeypatch):
    from app.intelligence import mcp_tools

    class FakeConn:
        provider_key, is_enabled, project_id = "mcp_analyst", True, None
        display_name = "Down server"
        credentials_encrypted = None
        config = {"server_url": "https://down.example.com/mcp", "analyst_tools": "x"}

    def boom(*a, **k):
        raise ProviderError("connection refused")

    monkeypatch.setattr(mcp_tools, "build_client", boom)
    monkeypatch.setattr(mcp_tools, "decrypt_credentials", lambda b: {})

    class FakeDB:
        def scalars(self, *a, **k):
            class R:
                def all(self_inner):
                    return [FakeConn()]
            return R()

    ts = mcp_tools.load_toolset(FakeDB(), "pid")
    assert ts.specs == [] and "connection refused" in ts.errors["Down server"]


def test_tool_count_is_capped(monkeypatch):
    from app.intelligence import mcp_tools

    names = [f"tool_{n}" for n in range(100)]

    class FakeConn:
        provider_key, is_enabled, project_id = "mcp_analyst", True, None
        display_name = "Many"
        credentials_encrypted = None
        config = {"server_url": "https://m.example.com/mcp", "analyst_tools": ",".join(names)}

    class FakeClient:
        def list_tools(self):
            return [{"name": n, "inputSchema": {"type": "object"}} for n in names]

    monkeypatch.setattr(mcp_tools, "build_client", lambda c, cfg: FakeClient())
    monkeypatch.setattr(mcp_tools, "decrypt_credentials", lambda b: {})

    class FakeDB:
        def scalars(self, *a, **k):
            class R:
                def all(self_inner):
                    return [FakeConn()]
            return R()

    assert len(mcp_tools.load_toolset(FakeDB(), "pid").specs) == mcp_tools.MAX_TOOLS

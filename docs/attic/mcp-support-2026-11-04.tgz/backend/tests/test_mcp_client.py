"""The MCP client and the MCP-backed backlink adapter.

Transport details (SSE vs JSON, session id, error frames) are where a protocol client goes wrong, so they are
covered directly rather than through the adapter.
"""
import json

import httpx
import pytest

from app.adapters.base import CollectResult, ProviderError
from app.adapters.mcp.backlinks import MCPBacklinksAdapter
from app.adapters.mcp.client import MCPClient, _parse_sse, tool_payload

URL = "https://mcp.example.com/mcp"


def mock_transport(monkeypatch, handler):
    """Replace httpx.post with a handler(payload, headers) -> httpx.Response."""
    def fake_post(url, json=None, headers=None, timeout=None, follow_redirects=None):
        return handler(json, headers or {})
    monkeypatch.setattr(httpx, "post", fake_post)


def json_response(result, *, status=200, headers=None):
    return httpx.Response(status, json={"jsonrpc": "2.0", "id": 1, "result": result},
                          headers={"content-type": "application/json", **(headers or {})})


# ------------------------------------------------------------------ transport
def test_parse_sse_takes_the_first_json_frame():
    body = 'event: message\ndata: {"jsonrpc":"2.0","id":1,"result":{"ok":true}}\n\n'
    assert _parse_sse(body) == {"jsonrpc": "2.0", "id": 1, "result": {"ok": True}}
    assert _parse_sse("data: [DONE]\n\n") is None
    assert _parse_sse("no frames here") is None


def test_client_reads_an_sse_response(monkeypatch):
    body = 'data: {"jsonrpc":"2.0","id":1,"result":{"tools":[{"name":"t"}]}}\n\n'
    mock_transport(monkeypatch, lambda p, h: httpx.Response(200, text=body,
                                                            headers={"content-type": "text/event-stream"}))
    assert MCPClient(URL).list_tools() == [{"name": "t"}]


def test_client_keeps_the_session_id_the_server_hands_out(monkeypatch):
    seen = []

    def handler(payload, headers):
        seen.append(headers.get("Mcp-Session-Id"))
        return json_response({"serverInfo": {"name": "demo"}}, headers={"mcp-session-id": "abc123"})

    mock_transport(monkeypatch, handler)
    c = MCPClient(URL)
    c.initialize()
    c.list_tools()
    assert seen[0] is None          # first call cannot know the id yet
    assert "abc123" in seen[1:]     # every later call carries it


def test_client_sends_protocol_version_and_accepts_both_content_types(monkeypatch):
    captured = {}
    mock_transport(monkeypatch, lambda p, h: (captured.update(h), json_response({}))[1])
    MCPClient(URL).list_tools()
    assert captured["MCP-Protocol-Version"]
    assert "text/event-stream" in captured["Accept"] and "application/json" in captured["Accept"]


def test_client_surfaces_a_jsonrpc_error(monkeypatch):
    mock_transport(monkeypatch, lambda p, h: httpx.Response(
        200, json={"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "No such method"}},
        headers={"content-type": "application/json"}))
    with pytest.raises(ProviderError, match="No such method"):
        MCPClient(URL).list_tools()


def test_client_surfaces_an_http_error(monkeypatch):
    mock_transport(monkeypatch, lambda p, h: httpx.Response(401, text="nope",
                                                            headers={"content-type": "application/json"}))
    with pytest.raises(ProviderError, match="HTTP 401"):
        MCPClient(URL).list_tools()


def test_client_refuses_a_private_address():
    with pytest.raises(ProviderError):
        MCPClient("http://127.0.0.1:9000/mcp")


def test_list_tools_follows_pagination_but_stops(monkeypatch):
    calls = {"n": 0}

    def handler(payload, headers):
        calls["n"] += 1
        return json_response({"tools": [{"name": f"t{calls['n']}"}], "nextCursor": "more"})

    mock_transport(monkeypatch, handler)
    tools = MCPClient(URL).list_tools()
    assert len(tools) == 10 and calls["n"] == 10        # bounded, never an infinite follow


# ------------------------------------------------------------------ tool results
def test_tool_payload_prefers_structured_content():
    assert tool_payload({"structuredContent": {"a": 1}, "content": [{"type": "text", "text": "ignored"}]}) == {"a": 1}


def test_tool_payload_parses_json_text_blocks():
    assert tool_payload({"content": [{"type": "text", "text": '{"items":[1,2]}'}]}) == {"items": [1, 2]}


def test_tool_payload_falls_back_to_raw_text_and_empty():
    assert tool_payload({"content": [{"type": "text", "text": "plain words"}]}) == "plain words"
    assert tool_payload({"content": []}) is None


def test_call_tool_raises_when_the_server_flags_an_error(monkeypatch):
    mock_transport(monkeypatch, lambda p, h: json_response(
        {"isError": True, "content": [{"type": "text", "text": "quota exceeded"}]}))
    with pytest.raises(ProviderError, match="quota exceeded"):
        MCPClient(URL).call_tool("refdomains", {})


# ------------------------------------------------------------------ adapter mapping
def adapter(**config):
    return MCPBacklinksAdapter(credentials={}, config={"server_url": URL, **config})


def test_adapter_templates_tool_arguments():
    a = adapter(domains_args='{"target": "{target}", "limit": {limit}}')
    assert a._args("domains_args", "acme.com", 50) == {"target": "acme.com", "limit": 50}


def test_adapter_rejects_argument_json_that_does_not_parse():
    with pytest.raises(ProviderError, match="not valid JSON"):
        adapter(domains_args="{not json}")._args("domains_args", "acme.com", 10)


def test_adapter_normalizes_a_tool_result_into_referring_domains():
    payload = {"items": [{"domain": "https://www.Ref.com/x", "backlinks": "9", "follow": 7, "dr": 61}]}
    rows = adapter(domains_items_path="items", map_backlinks="backlinks",
                   map_dofollow="follow", map_rating="dr").normalize(CollectResult(raw=payload, meta={}))
    assert rows == [{"referring_domain": "ref.com", "backlinks": 9, "dofollow": 7, "domain_rating": 61.0,
                     "first_seen": None, "last_seen": None, "example_url": None}]


def test_adapter_normalizes_individual_links_with_nofollow_inversion():
    payload = {"links": [{"from": "https://a.com/p", "to": "https://me.com/x", "text": "hi", "nf": True},
                         {"from": "https://b.com/p", "to": "https://me.com/y", "text": "yo", "nf": False}]}
    rows = adapter(links_items_path="links", map_url_from="from", map_url_to="to",
                   map_anchor="text", map_nofollow="nf").normalize_links(CollectResult(raw=payload, meta={}))
    assert [r["dofollow"] for r in rows] == [False, True]
    assert rows[0]["anchor"] == "hi" and rows[0]["referring_domain"] == "a.com"


def test_adapter_returns_nothing_rather_than_garbage_on_a_bad_path():
    payload = {"items": [{"domain": "a.com"}]}
    assert adapter(domains_items_path="wrong").normalize(CollectResult(raw=payload, meta={})) == []


def test_adapter_requires_a_tool_name():
    with pytest.raises(ProviderError, match="No MCP tool chosen"):
        adapter().collect({"target": "acme.com"})


def test_adapter_health_check_reports_a_missing_tool(monkeypatch):
    mock_transport(monkeypatch, lambda p, h: json_response(
        {"serverInfo": {"name": "demo"}, "tools": [{"name": "other_tool"}]}))
    res = adapter(domains_tool="refdomains").health_check()
    assert res.ok is False and "no tool called 'refdomains'" in res.message

"""MCP tools offered to the AI analyst.

Any connection whose provider key starts with `mcp_` can list tools in its `analyst_tools` config. Those tools are
merged into the analyst's own tool list, namespaced so an external name can never shadow an internal one, and
routed back to the server when the model calls them.

Only allowlisted tools are offered: the analyst calls tools unsupervised, so which ones it may reach is a
deliberate choice rather than everything a server happens to expose.
"""
from __future__ import annotations

import json
import re
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.adapters.base import ProviderError
from app.adapters.mcp.analyst import build_client
from app.adapters.mcp.client import tool_payload
from app.core.secrets import decrypt_credentials
from app.models import ProviderConnection

PREFIX = "mcp__"
MAX_TOOLS = 24          # keep the prompt (and its token cost) bounded
MAX_RESULT_CHARS = 20_000


def _slug(value: str) -> str:
    return re.sub(r"[^a-zA-Z0-9]+", "_", value or "server").strip("_").lower()[:20] or "server"


def qualified_name(connection: str, tool: str) -> str:
    """`mcp__<connection>__<tool>`, trimmed to the 64 characters tool names are limited to.

    Both halves are sanitised here rather than trusting the caller: a display name may contain anything, and an
    invalid character would be rejected by the model provider at call time.
    """
    return f"{PREFIX}{_slug(connection)}__{_slug(tool)}"[:64]


class MCPToolset:
    """The MCP tools available to one analysis run, and the routing back to their servers."""

    def __init__(self) -> None:
        self.specs: list[dict[str, Any]] = []
        self._routes: dict[str, tuple[dict[str, Any], dict[str, Any], str]] = {}
        self._clients: dict[str, Any] = {}
        self.errors: dict[str, str] = {}

    def __bool__(self) -> bool:
        return bool(self.specs)

    def handles(self, name: str) -> bool:
        return name.startswith(PREFIX)

    def call(self, name: str, args: dict[str, Any]) -> str:
        route = self._routes.get(name)
        if route is None:
            return json.dumps({"error": f"unknown MCP tool {name}"})
        creds, config, tool = route
        try:
            key = str(config.get("server_url"))
            client = self._clients.get(key)
            if client is None:
                client = self._clients[key] = build_client(creds, config)
            payload = tool_payload(client.call_tool(tool, args or {}))
        except ProviderError as exc:
            return json.dumps({"error": str(exc)[:500]})
        except Exception as exc:  # noqa: BLE001 — a bad tool must not end the analysis
            return json.dumps({"error": f"{type(exc).__name__}: {str(exc)[:400]}"})
        text = payload if isinstance(payload, str) else json.dumps(payload, default=str)
        return text[:MAX_RESULT_CHARS]


def load_toolset(db: Session, project_id: Any) -> MCPToolset:
    """Discover the allowlisted tools from every MCP connection visible to this project."""
    toolset = MCPToolset()
    conns = [c for c in db.scalars(select(ProviderConnection)).all()
             if c.provider_key.startswith(PREFIX.rstrip("_")) and c.is_enabled
             and c.project_id in (None, project_id)]
    for conn in conns:
        allowed = [t.strip() for t in str((conn.config or {}).get("analyst_tools") or "").split(",") if t.strip()]
        if not allowed:
            continue
        creds, config = decrypt_credentials(conn.credentials_encrypted), (conn.config or {})
        try:
            client = build_client(creds, config)
            available = {t.get("name"): t for t in client.list_tools()}
        except Exception as exc:  # noqa: BLE001 — one unreachable server must not block the analysis
            toolset.errors[conn.display_name] = str(exc)[:300]
            continue
        toolset._clients[str(config.get("server_url"))] = client
        slug = _slug(conn.display_name or conn.provider_key)
        for tool_name in allowed:
            tool = available.get(tool_name)
            if tool is None:
                toolset.errors[f"{conn.display_name}:{tool_name}"] = "not offered by the server"
                continue
            if len(toolset.specs) >= MAX_TOOLS:
                break
            name = qualified_name(slug, tool_name)
            schema = tool.get("inputSchema") or {"type": "object", "properties": {}}
            toolset.specs.append({
                "name": name,
                # Say where it came from: the model should know this is an external source, not GrowOS data.
                "description": f"[{conn.display_name}] {tool.get('description') or tool_name}"[:1000],
                "parameters": schema if isinstance(schema, dict) else {"type": "object", "properties": {}},
            })
            toolset._routes[name] = (creds, config, tool_name)
    return toolset

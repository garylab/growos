"""Minimal MCP client over the streamable HTTP transport.

Enough of the protocol to use a server as a data provider: initialize, list its tools, call one. Deliberately not a
full MCP implementation — no resources, prompts, sampling or notifications beyond the initialized handshake.

A streamable-HTTP server may answer a POST with either `application/json` (one response) or `text/event-stream`
(SSE frames), so both are parsed. Every URL goes through the SSRF-safe validator, so only public hosts are reachable.
"""
from __future__ import annotations

import json
from typing import Any

import httpx

from app.adapters.base import ProviderError
from app.core.safe_http import UnsafeURLError, validate_url

PROTOCOL_VERSION = "2025-06-18"
CLIENT_INFO = {"name": "growos", "version": "0.1.0"}


def _parse_sse(body: str) -> dict[str, Any] | None:
    """Return the first JSON-RPC message carried by an SSE stream."""
    for line in body.splitlines():
        if line.startswith("data:"):
            chunk = line[5:].strip()
            if not chunk or chunk == "[DONE]":
                continue
            try:
                return json.loads(chunk)
            except ValueError:
                continue
    return None


class MCPClient:
    """One short-lived session against an MCP server."""

    def __init__(self, url: str, *, headers: dict[str, str] | None = None, timeout: float = 60.0):
        try:
            self.url = validate_url(url)
        except UnsafeURLError as exc:
            raise ProviderError(str(exc)) from exc
        self.extra_headers = headers or {}
        self.timeout = timeout
        self.session_id: str | None = None
        self.server_info: dict[str, Any] = {}
        self._next_id = 0

    def _headers(self) -> dict[str, str]:
        h = {"Content-Type": "application/json",
             "Accept": "application/json, text/event-stream",
             "MCP-Protocol-Version": PROTOCOL_VERSION,
             **self.extra_headers}
        if self.session_id:
            h["Mcp-Session-Id"] = self.session_id
        return h

    def _rpc(self, method: str, params: dict[str, Any] | None = None, *, notify: bool = False) -> Any:
        self._next_id += 1
        payload: dict[str, Any] = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            payload["params"] = params
        if not notify:
            payload["id"] = self._next_id
        try:
            resp = httpx.post(self.url, json=payload, headers=self._headers(), timeout=self.timeout,
                              follow_redirects=False)
        except httpx.HTTPError as exc:
            raise ProviderError(f"Could not reach the MCP server: {exc}") from exc
        if sid := resp.headers.get("mcp-session-id"):
            self.session_id = sid
        if notify:
            return None
        if resp.status_code >= 400:
            raise ProviderError(f"MCP server returned HTTP {resp.status_code}: {resp.text[:300]}")
        content_type = resp.headers.get("content-type", "")
        if "text/event-stream" in content_type:
            message = _parse_sse(resp.text)
        else:
            try:
                message = resp.json()
            except ValueError as exc:
                raise ProviderError(f"MCP server did not return JSON: {resp.text[:200]}") from exc
        if message is None:
            raise ProviderError("MCP server sent no JSON-RPC message")
        if isinstance(message, list):           # batched response
            message = next((m for m in message if m.get("id") == self._next_id), message[0])
        if "error" in message:
            err = message["error"] or {}
            raise ProviderError(f"MCP error {err.get('code')}: {err.get('message')}")
        return message.get("result")

    def initialize(self) -> dict[str, Any]:
        result = self._rpc("initialize", {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {},
            "clientInfo": CLIENT_INFO,
        }) or {}
        self.server_info = result.get("serverInfo") or {}
        # The spec requires this notification before normal operation; servers may reject calls without it.
        try:
            self._rpc("notifications/initialized", {}, notify=True)
        except ProviderError:
            pass
        return result

    def list_tools(self) -> list[dict[str, Any]]:
        tools: list[dict[str, Any]] = []
        cursor = None
        for _ in range(10):                      # bounded: do not follow a server paginating forever
            params = {"cursor": cursor} if cursor else {}
            result = self._rpc("tools/list", params) or {}
            tools.extend(result.get("tools") or [])
            cursor = result.get("nextCursor")
            if not cursor:
                break
        return tools

    def call_tool(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        result = self._rpc("tools/call", {"name": name, "arguments": arguments}) or {}
        if result.get("isError"):
            raise ProviderError(f"MCP tool '{name}' failed: {_text_of(result)[:300]}")
        return result


def _text_of(result: dict[str, Any]) -> str:
    return "\n".join(c.get("text", "") for c in (result.get("content") or []) if c.get("type") == "text")


def tool_payload(result: dict[str, Any]) -> Any:
    """The useful data out of a tool result.

    Prefers `structuredContent` (typed output). Otherwise takes the text blocks and parses them as JSON when
    possible, since most servers return a JSON document as text.
    """
    if isinstance(result.get("structuredContent"), (dict, list)):
        return result["structuredContent"]
    text = _text_of(result).strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except ValueError:
        return text

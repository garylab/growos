"""Use any MCP server as a backlink provider.

Instead of writing a Python adapter per vendor, point this at an MCP server, pick one of its tools and say which
field is which. Because it registers in the `backlinks` category, the existing sync task and scorecard component
pick it up with no further changes.
"""
from __future__ import annotations

import json
from typing import Any, ClassVar

from app.adapters.backlinks.common import dedupe, dedupe_links, link_row, row
from app.adapters.base import (Capabilities, CollectResult, ConfigField, CredentialField, HealthResult,
                               ProviderAdapter, ProviderError, UsageEstimate)
from app.adapters.mcp.analyst import ANALYST_TOOLS_FIELD
from app.adapters.mcp.client import MCPClient, tool_payload


def _dig(obj: Any, path: str) -> Any:
    """Walk a dotted path like 'result.items.0.domain'. An empty path returns obj unchanged."""
    if not path:
        return obj
    cur = obj
    for part in path.split("."):
        if cur is None:
            return None
        if isinstance(cur, list):
            try:
                cur = cur[int(part)]
            except (ValueError, IndexError):
                return None
        elif isinstance(cur, dict):
            cur = cur.get(part)
        else:
            return None
    return cur


def _field(item: Any, path: str) -> Any:
    """An unmapped (blank) path means the source does not provide that field."""
    return _dig(item, path) if path else None


def _truthy(value: Any) -> bool:
    if isinstance(value, str):
        return value.strip().lower() not in ("", "false", "0", "no", "null")
    return bool(value)


class MCPBacklinksAdapter(ProviderAdapter):
    key: ClassVar[str] = "mcp_backlinks"
    category: ClassVar[str] = "backlinks"
    display_name: ClassVar[str] = "MCP server (backlinks)"
    description: ClassVar[str] = ("Connect any Model Context Protocol server over HTTP and use one of its tools as a "
                                  "backlink source. Discover the server's tools, pick one, map its fields — no code.")
    docs_url: ClassVar[str] = "https://modelcontextprotocol.io/docs/concepts/transports"
    credential_fields: ClassVar[list[CredentialField]] = [
        CredentialField("auth_token", "Auth token", secret=True, required=False,
                        help="Optional. Sent as the Authorization header using the scheme chosen below."),
    ]
    config_fields: ClassVar[list[ConfigField]] = [
        ConfigField("server_url", "MCP server URL", "string", "",
                    help="The streamable-HTTP endpoint, e.g. https://mcp.example.com/mcp"),
        ConfigField("auth_scheme", "Auth scheme", "select", "Bearer", ["Bearer", "none", "X-API-Key"]),
        ConfigField("domains_tool", "Tool: referring domains", "string", "",
                    help="Tool name to call. Use Discover tools to see what this server offers."),
        ConfigField("domains_args", "Arguments (JSON)", "string", '{"target": "{target}"}',
                    help="{target} is replaced with the site being checked."),
        ConfigField("domains_items_path", "Path to the list", "string", "",
                    help="Dotted path to the array inside the tool result, e.g. 'items'. Blank if it is the array."),
        ConfigField("map_domain", "Field: referring domain", "string", "domain"),
        ConfigField("map_backlinks", "Field: backlinks", "string", "backlinks"),
        ConfigField("map_dofollow", "Field: dofollow links", "string", ""),
        ConfigField("map_rating", "Field: domain rating", "string", ""),
        ConfigField("map_first_seen", "Field: first seen", "string", ""),
        ConfigField("map_last_seen", "Field: last seen", "string", ""),
        ConfigField("links_tool", "Tool: individual links", "string", "",
                    help="Optional second tool returning single links with their anchor text."),
        ConfigField("links_args", "Individual links: arguments (JSON)", "string", '{"target": "{target}"}'),
        ConfigField("links_items_path", "Individual links: path to the list", "string", ""),
        ConfigField("map_url_from", "Field: linking page URL", "string", "url_from"),
        ConfigField("map_url_to", "Field: target URL", "string", "url_to"),
        ConfigField("map_anchor", "Field: anchor text", "string", "anchor"),
        ConfigField("map_page_title", "Field: linking page title", "string", ""),
        ConfigField("map_nofollow", "Field: nofollow flag", "string", ""),
        ConfigField("limit", "Rows per sync", "number", 500),
        ANALYST_TOOLS_FIELD,
    ]

    def capabilities(self) -> Capabilities:
        return Capabilities(category="backlinks", measurement_type="observed",
                            features=["referring_domains", "backlinks", "mcp"],
                            notes="Whatever the connected MCP server's tool returns.")

    # ---------------------------------------------------------------- session
    def _client(self) -> MCPClient:
        url = str(self.config.get("server_url") or "").strip()
        if not url:
            raise ProviderError("Set the MCP server URL")
        token = self.credentials.get("auth_token")
        scheme = str(self.config.get("auth_scheme") or "Bearer")
        headers: dict[str, str] = {}
        if token and scheme == "Bearer":
            headers["Authorization"] = f"Bearer {token}"
        elif token and scheme == "X-API-Key":
            headers["X-API-Key"] = str(token)
        client = MCPClient(url, headers=headers)
        client.initialize()
        return client

    def discover_tools(self) -> list[dict[str, Any]]:
        """Tool name, description and input schema — used to populate the picker in the UI."""
        client = self._client()
        return [{"name": t.get("name"), "description": t.get("description") or "",
                 "input_schema": t.get("inputSchema") or {}} for t in client.list_tools()]

    def health_check(self) -> HealthResult:
        try:
            client = self._client()
            tools = client.list_tools()
            name = client.server_info.get("name") or "MCP server"
            chosen = str(self.config.get("domains_tool") or "")
            if chosen and chosen not in {t.get("name") for t in tools}:
                return HealthResult(False, f"{name} is reachable but has no tool called '{chosen}'",
                                    {"tools": [t.get("name") for t in tools]})
            return HealthResult(True, f"{name} reachable, {len(tools)} tool(s) available",
                                {"tools": [t.get("name") for t in tools][:25]})
        except Exception as exc:  # noqa: BLE001
            return HealthResult(False, f"MCP check failed: {exc}")

    def estimate_usage(self, request: dict[str, Any]) -> UsageEstimate:
        return UsageEstimate(requests=1, note="One MCP tool call (the server may bill its own upstream)")

    # ---------------------------------------------------------------- collection
    def _args(self, key: str, target: str, limit: Any) -> dict[str, Any]:
        raw = str(self.config.get(key) or "{}")
        filled = raw.replace("{target}", target).replace("{limit}", str(limit or self.config.get("limit") or 500))
        try:
            args = json.loads(filled)
        except ValueError as exc:
            raise ProviderError(f"Arguments for this tool are not valid JSON: {filled[:160]}") from exc
        if not isinstance(args, dict):
            raise ProviderError("Tool arguments must be a JSON object")
        return args

    def _call(self, tool_key: str, args_key: str, request: dict[str, Any]) -> CollectResult:
        tool = str(self.config.get(tool_key) or "").strip()
        if not tool:
            raise ProviderError(f"No MCP tool chosen for {tool_key.replace('_tool', '').replace('_', ' ')}")
        target = request["target"]
        args = self._args(args_key, target, request.get("limit"))
        client = self._client()
        payload = tool_payload(client.call_tool(tool, args))
        return CollectResult(raw=payload, meta={"target": target, "provider": self.key, "tool": tool,
                                                "arguments": args, "server": client.server_info})

    def _items(self, result: CollectResult, path_key: str) -> list[Any]:
        items = _dig(result.raw, str(self.config.get(path_key) or ""))
        if isinstance(items, dict):
            items = [items]
        if not isinstance(items, list):
            return []
        return items[:int(self.config.get("limit") or 500)]

    def collect(self, request: dict[str, Any]) -> CollectResult:
        return self._call("domains_tool", "domains_args", request)

    def normalize(self, result: CollectResult) -> list[dict[str, Any]]:
        out = []
        for item in self._items(result, "domains_items_path"):
            r = row(_field(item, str(self.config.get("map_domain") or "domain")),
                    backlinks=_field(item, str(self.config.get("map_backlinks") or "")) or 0,
                    dofollow=_field(item, str(self.config.get("map_dofollow") or "")) or 0,
                    domain_rating=_field(item, str(self.config.get("map_rating") or "")),
                    first_seen=_field(item, str(self.config.get("map_first_seen") or "")),
                    last_seen=_field(item, str(self.config.get("map_last_seen") or "")))
            if r:
                out.append(r)
        return dedupe(out)

    def collect_links(self, request: dict[str, Any]) -> CollectResult:
        return self._call("links_tool", "links_args", request)

    def normalize_links(self, result: CollectResult) -> list[dict[str, Any]]:
        nofollow_field = str(self.config.get("map_nofollow") or "")
        out = []
        for item in self._items(result, "links_items_path"):
            nofollow = _field(item, nofollow_field)
            r = link_row(_field(item, str(self.config.get("map_url_from") or "url_from")),
                         _field(item, str(self.config.get("map_url_to") or "url_to")),
                         anchor=_field(item, str(self.config.get("map_anchor") or "anchor")),
                         page_title=_field(item, str(self.config.get("map_page_title") or "")),
                         dofollow=not _truthy(nofollow) if nofollow_field else True,
                         domain_rating=_field(item, str(self.config.get("map_rating") or "")),
                         first_seen=_field(item, str(self.config.get("map_first_seen") or "")),
                         last_seen=_field(item, str(self.config.get("map_last_seen") or "")))
            if r:
                out.append(r)
        return dedupe_links(out)

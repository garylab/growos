"""Expose an MCP server's tools to the AI analyst.

The ingestion adapters need a field mapping because Python code consumes the result. The analyst does not — it
reads the tool's JSON Schema and the response itself — so a server connected here needs nothing but an allowlist
of which tools the analyst may call.

Separate from the data adapters so a server that is useful to the analyst but is not a data provider (a docs
server, an internal API, a search tool) can be connected on its own.
"""
from __future__ import annotations

from typing import Any, ClassVar

from app.adapters.base import (Capabilities, ConfigField, CredentialField, HealthResult, ProviderAdapter,
                               UsageEstimate)
from app.adapters.mcp.client import MCPClient


def build_client(credentials: dict[str, Any], config: dict[str, Any]) -> MCPClient:
    """One initialised session for a connection's MCP server."""
    from app.adapters.base import ProviderError

    url = str(config.get("server_url") or "").strip()
    if not url:
        raise ProviderError("Set the MCP server URL")
    token = credentials.get("auth_token")
    scheme = str(config.get("auth_scheme") or "Bearer")
    headers: dict[str, str] = {}
    if token and scheme == "Bearer":
        headers["Authorization"] = f"Bearer {token}"
    elif token and scheme == "X-API-Key":
        headers["X-API-Key"] = str(token)
    client = MCPClient(url, headers=headers)
    client.initialize()
    return client


ANALYST_TOOLS_FIELD = ConfigField(
    "analyst_tools", "Tools the AI analyst may call", "string", "",
    help=("Comma-separated tool names from this server. Empty means the analyst gets nothing from it. "
          "Only list tools you are happy for the analyst to call on its own."))


class MCPAnalystAdapter(ProviderAdapter):
    key: ClassVar[str] = "mcp_analyst"
    category: ClassVar[str] = "ai_tools"
    display_name: ClassVar[str] = "MCP server (AI analyst tools)"
    description: ClassVar[str] = ("Give the AI analyst tools from any Model Context Protocol server. The analyst "
                                  "reads each tool's schema itself, so no field mapping is needed — only an "
                                  "allowlist of the tools it may call.")
    docs_url: ClassVar[str] = "https://modelcontextprotocol.io/docs/concepts/tools"
    credential_fields: ClassVar[list[CredentialField]] = [
        CredentialField("auth_token", "Auth token", secret=True, required=False),
    ]
    config_fields: ClassVar[list[ConfigField]] = [
        ConfigField("server_url", "MCP server URL", "string", "", help="The streamable-HTTP endpoint."),
        ConfigField("auth_scheme", "Auth scheme", "select", "Bearer", ["Bearer", "none", "X-API-Key"]),
        ANALYST_TOOLS_FIELD,
    ]

    def capabilities(self) -> Capabilities:
        return Capabilities(category="ai_tools", measurement_type="observed", features=["analyst_tools", "mcp"],
                            notes="Tools are offered to the analyst; it decides whether to call them.")

    def _client(self) -> MCPClient:
        return build_client(self.credentials, self.config)

    def discover_tools(self) -> list[dict[str, Any]]:
        return [{"name": t.get("name"), "description": t.get("description") or "",
                 "input_schema": t.get("inputSchema") or {}} for t in self._client().list_tools()]

    def health_check(self) -> HealthResult:
        try:
            client = self._client()
            tools = client.list_tools()
            names = {t.get("name") for t in tools}
            name = client.server_info.get("name") or "MCP server"
            allowed = [t.strip() for t in str(self.config.get("analyst_tools") or "").split(",") if t.strip()]
            missing = [t for t in allowed if t not in names]
            if missing:
                return HealthResult(False, f"{name} is reachable but has no tool(s): {', '.join(missing)}",
                                    {"tools": sorted(n for n in names if n)})
            if not allowed:
                return HealthResult(True, f"{name} reachable, {len(tools)} tool(s) — none allowlisted for the analyst yet",
                                    {"tools": sorted(n for n in names if n)})
            return HealthResult(True, f"{name} reachable, analyst may call {len(allowed)} of {len(tools)} tool(s)",
                                {"allowed": allowed})
        except Exception as exc:  # noqa: BLE001
            return HealthResult(False, f"MCP check failed: {exc}")

    def estimate_usage(self, request: dict[str, Any]) -> UsageEstimate:
        return UsageEstimate(requests=0, note="Called only when the analyst chooses to")

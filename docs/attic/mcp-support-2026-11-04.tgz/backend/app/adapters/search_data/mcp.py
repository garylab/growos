"""Use any MCP server as a keyword/SERP provider — the search-data twin of the MCP backlinks adapter."""
from __future__ import annotations

import json
from typing import Any, ClassVar

from app.adapters.base import (Capabilities, CollectResult, ConfigField, CredentialField, HealthResult,
                               ProviderAdapter, ProviderError, UsageEstimate)
from app.adapters.mcp.backlinks import _dig, _field
from app.adapters.mcp.analyst import ANALYST_TOOLS_FIELD
from app.adapters.mcp.client import MCPClient, tool_payload
from app.adapters.search_data.common import best_per_keyword, dedupe_metrics, metric_row, ranked_row


class MCPSearchDataAdapter(ProviderAdapter):
    key: ClassVar[str] = "mcp_search_data"
    category: ClassVar[str] = "search_data"
    display_name: ClassVar[str] = "MCP server (keywords & rankings)"
    description: ClassVar[str] = ("Connect any Model Context Protocol server over HTTP and use its tools for keyword "
                                  "metrics and ranked keywords. Discover the tools, pick them, map the fields.")
    docs_url: ClassVar[str] = "https://modelcontextprotocol.io/docs/concepts/transports"
    credential_fields: ClassVar[list[CredentialField]] = [
        CredentialField("auth_token", "Auth token", secret=True, required=False),
    ]
    config_fields: ClassVar[list[ConfigField]] = [
        ConfigField("server_url", "MCP server URL", "string", "", help="The streamable-HTTP endpoint."),
        ConfigField("auth_scheme", "Auth scheme", "select", "Bearer", ["Bearer", "none", "X-API-Key"]),
        ConfigField("metrics_tool", "Tool: keyword metrics", "string", ""),
        ConfigField("metrics_args", "Keyword metrics: arguments (JSON)", "string", '{"keywords": "{keywords}"}',
                    help="{keywords} becomes a JSON array of the terms being priced."),
        ConfigField("metrics_items_path", "Keyword metrics: path to the list", "string", ""),
        ConfigField("map_keyword", "Field: keyword", "string", "keyword"),
        ConfigField("map_volume", "Field: search volume", "string", "search_volume"),
        ConfigField("map_difficulty", "Field: difficulty", "string", ""),
        ConfigField("map_cpc", "Field: CPC", "string", ""),
        ConfigField("ranked_tool", "Tool: ranked keywords", "string", ""),
        ConfigField("ranked_args", "Ranked keywords: arguments (JSON)", "string", '{"target": "{host}"}',
                    help="{host} is the site being analysed."),
        ConfigField("ranked_items_path", "Ranked keywords: path to the list", "string", ""),
        ConfigField("map_position", "Field: position", "string", "position"),
        ConfigField("map_url", "Field: ranking URL", "string", "url"),
        ConfigField("map_traffic", "Field: traffic", "string", ""),
        ConfigField("limit", "Rows per sync", "number", 500),
        ANALYST_TOOLS_FIELD,
    ]

    def capabilities(self) -> Capabilities:
        return Capabilities(category="search_data", measurement_type="estimated",
                            features=["keyword_metrics", "ranked_keywords", "mcp"],
                            notes="Whatever the connected MCP server's tools return.")

    def _client(self) -> MCPClient:
        url = str(self.config.get("server_url") or "").strip()
        if not url:
            raise ProviderError("Set the MCP server URL")
        token = self.credentials.get("auth_token")
        scheme = str(self.config.get("auth_scheme") or "Bearer")
        headers: dict[str, str] = {}
        if token and scheme == "Bearer":
            headers["Authorization"] = f"Bearer {token}"
        elif token and scheme == "X-API-Key":
            headers["X-API-Key"] = str(token)
        client = MCPClient(url, headers=headers)
        client.initialize()
        return client

    def discover_tools(self) -> list[dict[str, Any]]:
        return [{"name": t.get("name"), "description": t.get("description") or "",
                 "input_schema": t.get("inputSchema") or {}} for t in self._client().list_tools()]

    def health_check(self) -> HealthResult:
        try:
            client = self._client()
            tools = client.list_tools()
            name = client.server_info.get("name") or "MCP server"
            return HealthResult(True, f"{name} reachable, {len(tools)} tool(s) available",
                                {"tools": [t.get("name") for t in tools][:25]})
        except Exception as exc:  # noqa: BLE001
            return HealthResult(False, f"MCP check failed: {exc}")

    def estimate_usage(self, request: dict[str, Any]) -> UsageEstimate:
        return UsageEstimate(requests=1, note="One MCP tool call")

    def _args(self, key: str, substitutions: dict[str, Any]) -> dict[str, Any]:
        raw = str(self.config.get(key) or "{}")
        for name, value in substitutions.items():
            raw = raw.replace("{" + name + "}", json.dumps(value) if isinstance(value, list) else str(value))
        # A template may wrap the placeholder in quotes; a JSON array must not end up a string.
        raw = raw.replace('"[', "[").replace(']"', "]")
        try:
            args = json.loads(raw)
        except ValueError as exc:
            raise ProviderError(f"Arguments for this tool are not valid JSON: {raw[:160]}") from exc
        if not isinstance(args, dict):
            raise ProviderError("Tool arguments must be a JSON object")
        return args

    def _call(self, tool_key: str, args_key: str, substitutions: dict[str, Any]) -> CollectResult:
        tool = str(self.config.get(tool_key) or "").strip()
        if not tool:
            raise ProviderError(f"No MCP tool chosen for {tool_key.replace('_tool', '').replace('_', ' ')}")
        args = self._args(args_key, substitutions)
        client = self._client()
        payload = tool_payload(client.call_tool(tool, args))
        return CollectResult(raw=payload, meta={"provider": self.key, "tool": tool, "arguments": args,
                                                **{k: v for k, v in substitutions.items() if k != "keywords"}})

    def _items(self, result: CollectResult, path_key: str) -> list[Any]:
        items = _dig(result.raw, str(self.config.get(path_key) or ""))
        if isinstance(items, dict):
            items = [items]
        if not isinstance(items, list):
            return []
        return items[:int(self.config.get("limit") or 500)]

    def collect_keyword_metrics(self, request: dict[str, Any]) -> CollectResult:
        return self._call("metrics_tool", "metrics_args", {"keywords": list(request.get("keywords") or [])})

    def normalize_keyword_metrics(self, result: CollectResult) -> list[dict[str, Any]]:
        out = []
        for item in self._items(result, "metrics_items_path"):
            r = metric_row(_field(item, str(self.config.get("map_keyword") or "keyword")),
                           search_volume=_field(item, str(self.config.get("map_volume") or "")),
                           difficulty=_field(item, str(self.config.get("map_difficulty") or "")),
                           cpc=_field(item, str(self.config.get("map_cpc") or "")))
            if r:
                out.append(r)
        return dedupe_metrics(out)

    def collect_ranked_keywords(self, request: dict[str, Any]) -> CollectResult:
        return self._call("ranked_tool", "ranked_args", {"host": request["host"]})

    def normalize_ranked_keywords(self, result: CollectResult) -> list[dict[str, Any]]:
        out = []
        for item in self._items(result, "ranked_items_path"):
            r = ranked_row(_field(item, str(self.config.get("map_keyword") or "keyword")),
                           _field(item, str(self.config.get("map_position") or "position")),
                           url=_field(item, str(self.config.get("map_url") or "")),
                           search_volume=_field(item, str(self.config.get("map_volume") or "")),
                           traffic=_field(item, str(self.config.get("map_traffic") or "")),
                           difficulty=_field(item, str(self.config.get("map_difficulty") or "")))
            if r:
                out.append(r)
        return best_per_keyword(out)
